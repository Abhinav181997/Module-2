import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Employee;
import com.cg.SBU;

public class MAIN {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");

		SBU sbu = applicationContext.getBean("sbu", SBU.class);

		List<Employee> empList = sbu.getEmpList();
		
		System.out.println("Enter emp Id");
		int id = new Scanner(System.in).nextInt();
		
		for(Employee emp: empList) {
			if(emp.getEmployeeId() == id) {
				System.out.println("Employee Id   :"+emp.getEmployeeId()+"\n"
								 + "Employee Name :"+emp.getEmployeeName()+"\n"
								 + "Salary        :"+emp.getSalary());
			}
		}

	}

}
