import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.beans.Employee;

public class MainApp {
	
	
	   public static void main(String[] args) {
		   EntityManagerFactory emfactory = Persistence.createEntityManagerFactory("Eclipselink_JPA");
		      
		   EntityManager entitymanager = emfactory.createEntityManager();
		   entitymanager.getTransaction( ).begin();

		   Employee employee = new Employee(); 
		   employee.setFirstName("LL");
		   employee.setLastName("KK");

		   entitymanager.persist(employee);
		   entitymanager.getTransaction().commit();

		   entitymanager.close();
		   emfactory.close();
	}
}
